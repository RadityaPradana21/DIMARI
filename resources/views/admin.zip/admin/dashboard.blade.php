@extends('layouts.app')
@section('title', 'Admin Panel')

@section('content')
<div class="admin-container">

    <div class="admin-header">
        <h1 class="page-title">⚙️ Admin Panel</h1>
        <p class="page-sub">Kelola seluruh data platform DIMARI</p>
    </div>

    {{-- Stats --}}
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-num">{{ $totalUsers ?? 0 }}</div>
            <div class="stat-label">Total User</div>
        </div>
        <div class="stat-card">
            <div class="stat-num">{{ $totalModules ?? 0 }}</div>
            <div class="stat-label">Total Modul</div>
        </div>
        <div class="stat-card">
            <div class="stat-num">{{ $totalQuestions ?? 0 }}</div>
            <div class="stat-label">Total Soal</div>
        </div>
        <div class="stat-card">
            <div class="stat-num">{{ $totalQuizThisWeek ?? 0 }}</div>
            <div class="stat-label">Quiz Minggu Ini</div>
        </div>
    </div>

    {{-- Tab Bar --}}
    <div class="tab-bar">
        <button class="tab-btn active" onclick="switchTab('users', this)">👥 Users</button>
        <button class="tab-btn" onclick="switchTab('modules', this)">📚 Modul</button>
        <button class="tab-btn" onclick="switchTab('results', this)">📊 Hasil Quiz</button>
    </div>

    {{-- Tab: Users --}}
    <div id="tab-users" class="tab-content">
        <div class="data-table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Bergabung</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users ?? [] as $user)
                        <tr>
                            <td>{{ $user->id }}</td>
                            <td>{{ $user->username }}</td>
                            <td>{{ $user->email }}</td>
                            <td>
                                <span class="role-badge role-{{ $user->role }}">
                                    {{ strtoupper($user->role) }}
                                </span>
                            </td>
                            <td>{{ $user->created_at->format('d M Y') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">Belum ada user.</div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Tab: Modules --}}
    <div id="tab-modules" class="tab-content" style="display:none;">
        <div style="margin-bottom:1rem;">
            <a href="{{ route('admin.modules.create') }}" class="btn-primary">
                + Tambah Modul
            </a>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Modul</th>
                        <th>Jumlah Soal</th>
                        <th>Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($modules ?? [] as $mod)
                        <tr>
                            <td>{{ $mod->id }}</td>
                            <td>{{ $mod->title }}</td>
                            <td>{{ $mod->questions_count ?? 0 }}</td>
                            <td>{{ $mod->created_at->format('d M Y') }}</td>
                            <td class="action-cell">
                                <a href="{{ route('admin.modules.edit', $mod) }}"
                                   class="btn-edit">Edit</a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">Belum ada modul.</div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Tab: Quiz Results --}}
    <div id="tab-results" class="tab-content" style="display:none;">
        <div class="data-table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Modul</th>
                        <th>Skor</th>
                        <th>Minggu</th>
                        <th>Dikerjakan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($quizResults ?? [] as $result)
                        <tr>
                            <td>{{ $result->user->username ?? '-' }}</td>
                            <td>Modul {{ $result->module_id }}</td>
                            <td>
                                <span class="score-badge
                                    {{ $result->score == 100 ? 'perfect' : ($result->score >= 70 ? 'good' : 'low') }}">
                                    {{ $result->score }}
                                </span>
                            </td>
                            <td>{{ \Carbon\Carbon::parse($result->week_start)->format('d M Y') }}</td>
                            <td>{{ $result->created_at->format('d M Y H:i') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">Belum ada hasil quiz.</div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
function switchTab(name, btn) {

    // Simpan tab terakhir
    localStorage.setItem('adminActiveTab', name);

    document.querySelectorAll('.tab-content').forEach(t => {
        t.style.display = 'none';
    });

    document.querySelectorAll('.tab-btn').forEach(b => {
        b.classList.remove('active');
    });

    document.getElementById('tab-' + name).style.display = 'block';

    btn.classList.add('active');
}
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const savedTab = localStorage.getItem('adminActiveTab');

    if (!savedTab) return;

    const targetButton = [...document.querySelectorAll('.tab-btn')]
        .find(btn => btn.getAttribute('onclick')?.includes("'" + savedTab + "'"));

    if (targetButton) {
        targetButton.click();
    }

});
</script>
@endpush