@extends('layouts.app')

@section('title', 'Daftar Modul')

@section('content')

<div class="container">

    <h1>Daftar Modul</h1>

    <a href="{{ route('admin.modules.create') }}">
        Tambah Modul
    </a>

    <table border="1" cellpadding="10">

        <tr>
            <th>ID</th>
            <th>Judul</th>
            <th>Aksi</th>
        </tr>

        @foreach($modules as $module)
        <tr>
            <td>{{ $module->id }}</td>
            <td>{{ $module->title }}</td>

            <td>

                <a href="{{ route('admin.modules.show', $module) }}">
                    Detail
                </a>

                <a href="{{ route('admin.modules.edit', $module) }}">
                    Edit
                </a>

            </td>
        </tr>
        @endforeach

    </table>

</div>

@endsection