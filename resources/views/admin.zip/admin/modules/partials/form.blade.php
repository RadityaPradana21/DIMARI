@csrf

@if(isset($module))
    @method('PUT')
@endif

<div class="glass-card p-6">

    {{-- Judul Modul --}}
    <div class="mb-4">
        <label
            class="block text-xs tracking-[2px] uppercase mb-2"
            style="color:#8888aa">

            Judul Modul

        </label>

        <input
            type="text"
            name="title"
            class="form-input w-full"
            required
            placeholder="Contoh: Social Media Marketing"
            value="{{ old('title', $module->title ?? '') }}">
    </div>

    {{-- Deskripsi --}}
    <div class="mb-4">
        <label
            class="block text-xs tracking-[2px] uppercase mb-2"
            style="color:#8888aa">

            Deskripsi Singkat

        </label>

        <textarea
            name="description"
            class="form-input w-full"
            rows="2"
            placeholder="Deskripsi singkat modul ini...">{{ old('description', $module->description ?? '') }}</textarea>
    </div>

    {{-- Konten --}}
    <div class="mb-4">
        <label
            class="block text-xs tracking-[2px] uppercase mb-2"
            style="color:#8888aa">

            Konten Materi

        </label>

        <textarea
            name="content"
            class="form-input w-full"
            rows="8"
            placeholder="Isi materi lengkap...">{{ old('content', $module->content ?? '') }}</textarea>
    </div>

    {{-- Urutan Modul --}}
    <div class="mb-5">
        <label
            class="block text-xs tracking-[2px] uppercase mb-2"
            style="color:#8888aa">

            Nomor Urut

        </label>

        <input
            type="number"
            name="order_num"
            min="1"
            required
            class="form-input w-full"
            value="{{ old('order_num', $module->order_num ?? 1) }}">
    </div>

    {{-- Validation Error --}}
    @if($errors->any())
        <div class="mb-4">
            <div class="rounded p-3 bg-red-500/10 border border-red-500/20">

                @foreach($errors->all() as $error)
                    <div class="text-sm text-red-400">
                        {{ $error }}
                    </div>
                @endforeach

            </div>
        </div>
    @endif

    {{-- Tombol --}}
    <div class="flex gap-3">

        <button
            type="submit"
            class="btn-primary flex-1">

            {{ isset($module)
                ? 'UPDATE MODUL →'
                : 'SIMPAN MODUL →' }}

        </button>

        <a
            href="{{ route('admin.index') }}"
            class="btn-secondary">

            Batal

        </a>

    </div>

</div>